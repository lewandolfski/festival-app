export const environment = {
  production: false,
  festivalApiUrl: 'http://localhost:9090',
  reviewApiUrl: 'http://localhost:8080'
};