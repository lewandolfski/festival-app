import { Component } from '@angular/core';

@Component({
  selector: 'lib-shared-lib',
  standalone: true,
  imports: [],
  template: `
    <p>
      shared-lib works!
    </p>
  `,
  styles: ``
})
export class SharedLibComponent {

}
